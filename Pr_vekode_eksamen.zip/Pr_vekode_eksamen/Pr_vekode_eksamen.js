let tank1;
let tank2;
var grid = 20;

function setup() {
  createCanvas(600, 400);
  tank1 = new Tank(200, 200);
  tank2 = new Tank(400, 200, 100);
  frameRate(10);
  pickLocation();
}

function pickLocation() {
  var kolonne = floor(width/grid);
  var række = floor(height/grid);
  tank1 = createVector(floor(random(kolonne)), floor(random(række)));
  tank1.mult(grid);
}


function draw() {
  background(51);

  if (tank1.intersects(tank2)) {
    tank1.x = 20;
    tank1.y= 20;
    tank2.x = pickLocation();
  }


  tank1.show();
 // tank2.show();
  tank1.move();
}


function keyPressed() { //"bev" står for bevægelse

  if (keyCode === UP_ARROW) {
    tank.bev(0, -1);
  } else if (keyCode === DOWN_ARROW) {
    tank.bev(0, 1);
  } else if (keyCode === LEFT_ARROW) {
    tank.bev(-1, 0);
  } else if (keyCode === RIGHT_ARROW) {
    tank.bev(1, 0);
  }
}


class Tank {
  constructor(x, y) {
    this.x = 0;
    this.y = 0;
    this.xspeed = 1;  //værdi for farten på x aksen
    this.yspeed = 0;  //værdi for farten på y aksen
  }

  intersects(other) {
    let d = dist(this.x, this.y, grid, grid);
    return d < grid + grid;
   //  if (d < grid + grid) {
   //    return true;
   //  } else {
   //    return false;
   //  }
  }

  contains(px, py) {
    let d = dist(px, py, this.x, this.y);
    if (d < this.r) {
      return true;
    } else {
      return false;
    }
  }

  move() {
    this.x = this.x + this.xspeed * grid;
    this.y = this.y + this.yspeed * grid;

    this.x = constrain(this.x, 0, width - grid);
    this.y = constrain(this.y, 0, width - grid);
  }

  bev() {
    this.xspeed = x;
    this.yspeed = y;
  }

  show() {
    fill(255);
    rect(this.x, this.y, grid, grid);
  }
}
